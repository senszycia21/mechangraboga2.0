# MECHAN-The-Card-Game
The card game with Mechanik's teachers 

Trailer - https://youtu.be/Slz3vTqsKLg
